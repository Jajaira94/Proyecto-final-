package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {
    // URL de conexión a tu base de datos
    private static final String URL = "jdbc:mysql://localhost:3306/gestion_veterinaria";
    private static final String USER = "root";
    private static final String PASSWORD = "1234"; //mi contraseña

    // Método para conectar
    public static Connection conectar() {
        Connection conexion = null;
        try {
            conexion = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Conexión exitosa a MySQL");
        } catch (SQLException e) {
            System.err.println("Error de conexión: " + e.getMessage());
        }
        return conexion;
    }
}