package Conexion;

import java.sql.Connection;

public class PruebaConexion {
    public static void main(String[] args) {
        Connection con = ConexionBD.conectar();
        if (con != null) {
            System.out.println("Conexión probada correctamente.");
        } else {
            System.out.println("Error al conectar.");
        }
    }
}