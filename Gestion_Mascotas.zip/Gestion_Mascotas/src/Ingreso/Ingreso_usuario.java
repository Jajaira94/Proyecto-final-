package Ingreso;

import Conexion.ConexionBD;
import java.sql.*;
import javax.swing.*;

public class Ingreso_usuario extends JFrame {
    private JTextField txtUsuario;
    private JPasswordField txtPassword;
    private JButton btnIngresar;

    public Ingreso_usuario() {
        setTitle("Ingreso de Cuenta");
        setSize(300, 200);
        setLayout(null);
        setLocationRelativeTo(null);

        JLabel lblUsuario = new JLabel("Usuario:");
        lblUsuario.setBounds(20, 20, 80, 25);
        add(lblUsuario);

        txtUsuario = new JTextField();
        txtUsuario.setBounds(100, 20, 150, 25);
        add(txtUsuario);

        JLabel lblPassword = new JLabel("Contraseña:");
        lblPassword.setBounds(20, 60, 80, 25);
        add(lblPassword);

        txtPassword = new JPasswordField();
        txtPassword.setBounds(100, 60, 150, 25);
        add(txtPassword);

        btnIngresar = new JButton("Ingresar");
        btnIngresar.setBounds(100, 100, 100, 25);
        btnIngresar.addActionListener(e -> login());
        add(btnIngresar);

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void login() {
        String usuario = txtUsuario.getText();
        String pass = new String(txtPassword.getPassword());

        try (Connection con = ConexionBD.conectar()) {
            String sql = "SELECT * FROM usuarios WHERE nombre_usuario=? AND contraseña=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, usuario);
            ps.setString(2, pass);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String rol = rs.getString("rol");
                JOptionPane.showMessageDialog(this, "✅ Bienvenido: " + usuario + " (" + rol + ")");

                if ("admin".equalsIgnoreCase(rol)) {
                    new Vista.MenuAdmin().setVisible(true);
                } else {
                    new Vista.MenuCajero().setVisible(true);
                }
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "❌ Usuario o contraseña incorrectos");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        new Ingreso_usuario();
    }
}
