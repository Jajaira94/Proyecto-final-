package Vista;

import javax.swing.*;

public class MenuCajero extends JFrame {

    public MenuCajero() {
        setTitle("Menú Cajero");
        setSize(300, 200);
        setLayout(null);
        setLocationRelativeTo(null);

        JButton btnMascota = new JButton("Registro Mascota");
        btnMascota.setBounds(50, 20, 200, 30);
        btnMascota.addActionListener(e -> new CRUDMascotas());
        add(btnMascota);

        JButton btnControl = new JButton("Registro Controles");
        btnControl.setBounds(50, 60, 200, 30);
        btnControl.addActionListener(e -> new CRUDControl());
        add(btnControl);

        JButton btnFactura = new JButton("Registro Factura");
        btnFactura.setBounds(50, 100, 200, 30);
        btnFactura.addActionListener(e -> new CRUDFactura());
        add(btnFactura);

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String[] args) {
        new MenuCajero();
    }
}
