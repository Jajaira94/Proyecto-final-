package Vista;

import Conexion.ConexionBD;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class CRUDControl extends JFrame {

    private JTable table;
    private DefaultTableModel model;
    private JTextField txtFecha, txtDescripcion, txtVeterinario, txtIdMascota;
    private JButton btnAgregar, btnActualizar, btnEliminar, btnCargar;

    public CRUDControl() {
        setTitle("Gestión de Controles Médicos");
        setSize(850, 450);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // 🔹 Panel superior (formulario)
        JPanel panelForm = new JPanel();
        panelForm.setBorder(BorderFactory.createTitledBorder("Datos Control Médico"));
        panelForm.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        // Fecha
        gbc.gridx = 0; gbc.gridy = 0;
        panelForm.add(new JLabel("Fecha (YYYY-MM-DD):"), gbc);

        gbc.gridx = 1;
        txtFecha = new JTextField(10);
        panelForm.add(txtFecha, gbc);

        // Veterinario
        gbc.gridx = 2;
        panelForm.add(new JLabel("Veterinario:"), gbc);

        gbc.gridx = 3;
        txtVeterinario = new JTextField(10);
        panelForm.add(txtVeterinario, gbc);

        // Descripción
        gbc.gridx = 0; gbc.gridy = 1;
        panelForm.add(new JLabel("Descripción:"), gbc);

        gbc.gridx = 1; gbc.gridwidth = 3;
        txtDescripcion = new JTextField(25);
        panelForm.add(txtDescripcion, gbc);
        gbc.gridwidth = 1;

        // ID Mascota
        gbc.gridx = 0; gbc.gridy = 2;
        panelForm.add(new JLabel("ID Mascota:"), gbc);

        gbc.gridx = 1;
        txtIdMascota = new JTextField(5);
        panelForm.add(txtIdMascota, gbc);

        // Botones
        JPanel panelBotones = new JPanel(new FlowLayout());
        btnAgregar = new JButton("Agregar");
        btnActualizar = new JButton("Actualizar");
        btnEliminar = new JButton("Eliminar");
        btnCargar = new JButton("Cargar Datos");

        panelBotones.add(btnAgregar);
        panelBotones.add(btnActualizar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnCargar);

        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 4;
        panelForm.add(panelBotones, gbc);

        add(panelForm, BorderLayout.NORTH);

        // 🔹 Tabla
        model = new DefaultTableModel(new String[]{"ID", "Fecha", "Descripción", "Veterinario", "ID Mascota"}, 0);
        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);

        // 🔹 Listeners
        btnAgregar.addActionListener(e -> agregarControl());
        btnActualizar.addActionListener(e -> actualizarControl());
        btnEliminar.addActionListener(e -> eliminarControl());
        btnCargar.addActionListener(e -> cargarControles());

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    // 🔹 Métodos CRUD
    private void agregarControl() {
        try (Connection con = ConexionBD.conectar()) {
            String sql = "INSERT INTO controles_medicos (fecha, descripcion, veterinario, id_mascota) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, txtFecha.getText());
            ps.setString(2, txtDescripcion.getText());
            ps.setString(3, txtVeterinario.getText());
            ps.setInt(4, Integer.parseInt(txtIdMascota.getText()));
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Control médico agregado");
            cargarControles();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void actualizarControl() {
        int fila = table.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un control para actualizar");
            return;
        }
        int id = Integer.parseInt(model.getValueAt(fila, 0).toString());
        try (Connection con = ConexionBD.conectar()) {
            String sql = "UPDATE controles_medicos SET fecha=?, descripcion=?, veterinario=?, id_mascota=? WHERE id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, txtFecha.getText());
            ps.setString(2, txtDescripcion.getText());
            ps.setString(3, txtVeterinario.getText());
            ps.setInt(4, Integer.parseInt(txtIdMascota.getText()));
            ps.setInt(5, id);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Control médico actualizado");
            cargarControles();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void eliminarControl() {
        int fila = table.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un control para eliminar");
            return;
        }
        int id = Integer.parseInt(model.getValueAt(fila, 0).toString());
        try (Connection con = ConexionBD.conectar()) {
            String sql = "DELETE FROM controles_medicos WHERE id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Control médico eliminado");
            cargarControles();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void cargarControles() {
        model.setRowCount(0);
        try (Connection con = ConexionBD.conectar()) {
            String sql = "SELECT * FROM controles_medicos";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("fecha"),
                        rs.getString("descripcion"),
                        rs.getString("veterinario"),
                        rs.getInt("id_mascota")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        new CRUDControl();
    }
}
