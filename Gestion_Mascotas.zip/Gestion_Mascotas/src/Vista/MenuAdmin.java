package Vista;

import javax.swing.*;

public class MenuAdmin extends JFrame {

    public MenuAdmin() {
        setTitle("Menú Administración");
        setSize(300, 250);
        setLayout(null);
        setLocationRelativeTo(null);

        JButton btnDueno = new JButton("Gestionar Dueño");
        btnDueno.setBounds(50, 20, 200, 30);
        btnDueno.addActionListener(e -> new CRUDDueños());
        add(btnDueno);

        JButton btnMascota = new JButton("Gestionar Mascotas");
        btnMascota.setBounds(50, 60, 200, 30);
        btnMascota.addActionListener(e -> new CRUDMascotas());
        add(btnMascota);

        JButton btnControles = new JButton("Controles Médicos");
        btnControles.setBounds(50, 100, 200, 30);
        btnControles.addActionListener(e -> new CRUDControl());
        add(btnControles);

        JButton btnReportes = new JButton("Gestionar Reportes");
        btnReportes.setBounds(50, 140, 200, 30);
        add(btnReportes);

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String[] args) {
        new MenuAdmin();
    }
}
