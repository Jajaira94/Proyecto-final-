package Vista;

import Conexion.ConexionBD;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class CRUDFactura extends JFrame {

    private JTable table;
    private DefaultTableModel model;
    private JTextField txtFecha, txtIdMascota, txtMonto;
    private JButton btnAgregar, btnActualizar, btnEliminar, btnCargar;

    public CRUDFactura() {
        setTitle("Gestión de Facturas");
        setSize(700, 450);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // 🔹 Panel superior (formulario)
        JPanel panelForm = new JPanel();
        panelForm.setBorder(BorderFactory.createTitledBorder("Datos Factura"));
        panelForm.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        // Fecha
        gbc.gridx = 0; gbc.gridy = 0;
        panelForm.add(new JLabel("Fecha (YYYY-MM-DD):"), gbc);

        gbc.gridx = 1;
        txtFecha = new JTextField(10);
        panelForm.add(txtFecha, gbc);

        // ID Mascota
        gbc.gridx = 2;
        panelForm.add(new JLabel("ID Mascota:"), gbc);

        gbc.gridx = 3;
        txtIdMascota = new JTextField(5);
        panelForm.add(txtIdMascota, gbc);

        // Monto Total
        gbc.gridx = 0; gbc.gridy = 1;
        panelForm.add(new JLabel("Monto Total:"), gbc);

        gbc.gridx = 1;
        txtMonto = new JTextField(10);
        panelForm.add(txtMonto, gbc);

        // Botones
        JPanel panelBotones = new JPanel(new FlowLayout());
        btnAgregar = new JButton("Agregar");
        btnActualizar = new JButton("Actualizar");
        btnEliminar = new JButton("Eliminar");
        btnCargar = new JButton("Cargar Datos");

        panelBotones.add(btnAgregar);
        panelBotones.add(btnActualizar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnCargar);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 4;
        panelForm.add(panelBotones, gbc);

        add(panelForm, BorderLayout.NORTH);

        // 🔹 Tabla
        model = new DefaultTableModel(new String[]{"ID", "Fecha", "ID Mascota", "Monto Total"}, 0);
        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);

        // 🔹 Listeners
        btnAgregar.addActionListener(e -> agregarFactura());
        btnActualizar.addActionListener(e -> actualizarFactura());
        btnEliminar.addActionListener(e -> eliminarFactura());
        btnCargar.addActionListener(e -> cargarFacturas());

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    // 🔹 Métodos CRUD
    private void agregarFactura() {
        try (Connection con = ConexionBD.conectar()) {
            String sql = "INSERT INTO facturas (fecha, id_mascota, monto_total) VALUES (?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, txtFecha.getText());
            ps.setInt(2, Integer.parseInt(txtIdMascota.getText()));
            ps.setDouble(3, Double.parseDouble(txtMonto.getText()));
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Factura agregada");
            cargarFacturas();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void actualizarFactura() {
        int fila = table.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione una factura para actualizar");
            return;
        }
        int id = Integer.parseInt(model.getValueAt(fila, 0).toString());
        try (Connection con = ConexionBD.conectar()) {
            String sql = "UPDATE facturas SET fecha=?, id_mascota=?, monto_total=? WHERE id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, txtFecha.getText());
            ps.setInt(2, Integer.parseInt(txtIdMascota.getText()));
            ps.setDouble(3, Double.parseDouble(txtMonto.getText()));
            ps.setInt(4, id);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Factura actualizada");
            cargarFacturas();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void eliminarFactura() {
        int fila = table.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione una factura para eliminar");
            return;
        }
        int id = Integer.parseInt(model.getValueAt(fila, 0).toString());
        try (Connection con = ConexionBD.conectar()) {
            String sql = "DELETE FROM facturas WHERE id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Factura eliminada");
            cargarFacturas();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void cargarFacturas() {
        model.setRowCount(0);
        try (Connection con = ConexionBD.conectar()) {
            String sql = "SELECT * FROM facturas";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("fecha"),
                        rs.getInt("id_mascota"),
                        rs.getDouble("monto_total")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        new CRUDFactura();
    }
}
