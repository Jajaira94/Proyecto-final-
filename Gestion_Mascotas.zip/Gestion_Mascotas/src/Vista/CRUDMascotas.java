package Vista;

import Conexion.ConexionBD;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class CRUDMascotas extends JFrame {

    private JTable table;
    private DefaultTableModel model;
    private JTextField txtNombre, txtEspecie, txtRaza, txtEdad, txtIdDueno;
    private JButton btnAgregar, btnActualizar, btnEliminar, btnCargar;

    public CRUDMascotas() {
        setTitle("Gestión de Mascotas");
        setSize(800, 450);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // 🔹 Panel superior (formulario)
        JPanel panelForm = new JPanel();
        panelForm.setBorder(BorderFactory.createTitledBorder("Datos Mascota"));
        panelForm.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        // Nombre
        gbc.gridx = 0; gbc.gridy = 0;
        panelForm.add(new JLabel("Nombre:"), gbc);

        gbc.gridx = 1;
        txtNombre = new JTextField(10);
        panelForm.add(txtNombre, gbc);

        // Especie
        gbc.gridx = 2;
        panelForm.add(new JLabel("Especie:"), gbc);

        gbc.gridx = 3;
        txtEspecie = new JTextField(10);
        panelForm.add(txtEspecie, gbc);

        // Raza
        gbc.gridx = 0; gbc.gridy = 1;
        panelForm.add(new JLabel("Raza:"), gbc);

        gbc.gridx = 1;
        txtRaza = new JTextField(10);
        panelForm.add(txtRaza, gbc);

        // Edad
        gbc.gridx = 2;
        panelForm.add(new JLabel("Edad:"), gbc);

        gbc.gridx = 3;
        txtEdad = new JTextField(5);
        panelForm.add(txtEdad, gbc);

        // ID Dueño
        gbc.gridx = 0; gbc.gridy = 2;
        panelForm.add(new JLabel("ID Dueño:"), gbc);

        gbc.gridx = 1;
        txtIdDueno = new JTextField(5);
        panelForm.add(txtIdDueno, gbc);

        // Botones
        JPanel panelBotones = new JPanel(new FlowLayout());
        btnAgregar = new JButton("Agregar");
        btnActualizar = new JButton("Actualizar");
        btnEliminar = new JButton("Eliminar");
        btnCargar = new JButton("Cargar Datos");

        panelBotones.add(btnAgregar);
        panelBotones.add(btnActualizar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnCargar);

        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 4;
        panelForm.add(panelBotones, gbc);

        add(panelForm, BorderLayout.NORTH);

        // 🔹 Tabla
        model = new DefaultTableModel(new String[]{"ID", "Nombre", "Especie", "Raza", "Edad", "ID Dueño"}, 0);
        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);

        // 🔹 Listeners
        btnAgregar.addActionListener(e -> agregarMascota());
        btnActualizar.addActionListener(e -> actualizarMascota());
        btnEliminar.addActionListener(e -> eliminarMascota());
        btnCargar.addActionListener(e -> cargarMascotas());

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    // 🔹 Métodos CRUD
    private void agregarMascota() {
        try (Connection con = ConexionBD.conectar()) {
            String sql = "INSERT INTO mascotas (nombre, especie, raza, edad, id_dueno) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, txtNombre.getText());
            ps.setString(2, txtEspecie.getText());
            ps.setString(3, txtRaza.getText());
            ps.setInt(4, Integer.parseInt(txtEdad.getText()));
            ps.setInt(5, Integer.parseInt(txtIdDueno.getText()));
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Mascota agregada correctamente");
            cargarMascotas();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void actualizarMascota() {
        int fila = table.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione una mascota para actualizar");
            return;
        }
        int id = Integer.parseInt(model.getValueAt(fila, 0).toString());
        try (Connection con = ConexionBD.conectar()) {
            String sql = "UPDATE mascotas SET nombre=?, especie=?, raza=?, edad=?, id_dueno=? WHERE id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, txtNombre.getText());
            ps.setString(2, txtEspecie.getText());
            ps.setString(3, txtRaza.getText());
            ps.setInt(4, Integer.parseInt(txtEdad.getText()));
            ps.setInt(5, Integer.parseInt(txtIdDueno.getText()));
            ps.setInt(6, id);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Mascota actualizada");
            cargarMascotas();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void eliminarMascota() {
        int fila = table.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione una mascota para eliminar");
            return;
        }
        int id = Integer.parseInt(model.getValueAt(fila, 0).toString());
        try (Connection con = ConexionBD.conectar()) {
            String sql = "DELETE FROM mascotas WHERE id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Mascota eliminada");
            cargarMascotas();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void cargarMascotas() {
        model.setRowCount(0);
        try (Connection con = ConexionBD.conectar()) {
            String sql = "SELECT * FROM mascotas";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("especie"),
                        rs.getString("raza"),
                        rs.getInt("edad"),
                        rs.getInt("id_dueno")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        new CRUDMascotas();
    }
}
