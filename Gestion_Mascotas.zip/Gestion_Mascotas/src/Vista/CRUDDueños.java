package Vista;

import Conexion.ConexionBD;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class CRUDDueños extends JFrame {

    private JTable table;
    private DefaultTableModel model;
    private JTextField txtNombre, txtTelefono, txtDireccion;
    private JButton btnAgregar, btnActualizar, btnEliminar, btnCargar;

    public CRUDDueños() {
        setTitle("Gestión de Dueños");
        setSize(700, 400);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // 🔹 Panel superior (formulario)
        JPanel panelForm = new JPanel();
        panelForm.setBorder(BorderFactory.createTitledBorder("Datos Dueño"));
        panelForm.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); // Espaciado

        // Nombre
        gbc.gridx = 0; gbc.gridy = 0;
        panelForm.add(new JLabel("Nombre:"), gbc);

        gbc.gridx = 1;
        txtNombre = new JTextField(15);
        panelForm.add(txtNombre, gbc);

        // Teléfono
        gbc.gridx = 2;
        panelForm.add(new JLabel("Teléfono:"), gbc);

        gbc.gridx = 3;
        txtTelefono = new JTextField(10);
        panelForm.add(txtTelefono, gbc);

        // Dirección
        gbc.gridx = 0; gbc.gridy = 1;
        panelForm.add(new JLabel("Dirección:"), gbc);

        gbc.gridx = 1; gbc.gridwidth = 3;
        txtDireccion = new JTextField(25);
        panelForm.add(txtDireccion, gbc);
        gbc.gridwidth = 1;

        // Botones
        JPanel panelBotones = new JPanel(new FlowLayout());
        btnAgregar = new JButton("Agregar");
        btnActualizar = new JButton("Actualizar");
        btnEliminar = new JButton("Eliminar");
        btnCargar = new JButton("Cargar Datos");

        panelBotones.add(btnAgregar);
        panelBotones.add(btnActualizar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnCargar);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 4;
        panelForm.add(panelBotones, gbc);

        add(panelForm, BorderLayout.NORTH);

        // 🔹 Tabla
        model = new DefaultTableModel(new String[]{"ID", "Nombre", "Teléfono", "Dirección"}, 0);
        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);

        // 🔹 Listeners
        btnAgregar.addActionListener(e -> agregarDueño());
        btnActualizar.addActionListener(e -> actualizarDueño());
        btnEliminar.addActionListener(e -> eliminarDueño());
        btnCargar.addActionListener(e -> cargarDueños());

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    // 🔹 Métodos CRUD
    private void agregarDueño() {
        try (Connection con = ConexionBD.conectar()) {
            String sql = "INSERT INTO duenos (nombre, telefono, direccion) VALUES (?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, txtNombre.getText());
            ps.setString(2, txtTelefono.getText());
            ps.setString(3, txtDireccion.getText());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Dueño agregado correctamente");
            cargarDueños();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void actualizarDueño() {
        int fila = table.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un dueño para actualizar");
            return;
        }
        int id = Integer.parseInt(model.getValueAt(fila, 0).toString());
        try (Connection con = ConexionBD.conectar()) {
            String sql = "UPDATE duenos SET nombre=?, telefono=?, direccion=? WHERE id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, txtNombre.getText());
            ps.setString(2, txtTelefono.getText());
            ps.setString(3, txtDireccion.getText());
            ps.setInt(4, id);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Dueño actualizado");
            cargarDueños();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void eliminarDueño() {
        int fila = table.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un dueño para eliminar");
            return;
        }
        int id = Integer.parseInt(model.getValueAt(fila, 0).toString());
        try (Connection con = ConexionBD.conectar()) {
            String sql = "DELETE FROM duenos WHERE id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Dueño eliminado");
            cargarDueños();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void cargarDueños() {
        model.setRowCount(0);
        try (Connection con = ConexionBD.conectar()) {
            String sql = "SELECT * FROM duenos";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("telefono"),
                        rs.getString("direccion")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        new CRUDDueños();
    }
}
