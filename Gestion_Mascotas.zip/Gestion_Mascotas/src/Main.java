
import Ingreso.Ingreso_usuario;

public class Main {
    public static void main(String[] args) {
        // Arrancar la aplicación desde la pantalla de login
        new Ingreso_usuario();
    }
}
